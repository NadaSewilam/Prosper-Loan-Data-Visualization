## Dataset Overview
###### This data set contains 113,937 loans
 with 81 variables on each loan, including loan amount, borrower rate (or interest rate),
 current loan status, borrower income, and many others. 

### My main focus on this data set is the Borrowers themselves interms of how their employment status and their prosper rating affects the loan they need.

## Exploration observations

##### Most borrowers are employed
##### I found out that half of the borrowers own a home while the other half don't.
##### The majority of borrowers are from california
##### Most loans are needed for Debt consolidation
##### Prosper Rating type C has the highest number of homeowners and borrowers currently in group
##### Employed borrowers has the highest Borrower rate, Borrower APR and Number of trades
##### Most Borrowers come from California
##### There is a positive realtionship between the number of investors and the amount of loan



## Summary Findings

##### It is apparent that ProsperRating type A ,AA & B have the highest loan amounts along with high number of investors
##### We can observe that prosper rating type C has highest interest rate with aveage loan term of 36 months
##### Borrowers who work full time or employed have the highest amounts of loans but number of investors in full-time borrowers are higher
##### Part-time borrowers have the highest recommendations.
##### Total trades are almost equal between borrowers of different employment status.